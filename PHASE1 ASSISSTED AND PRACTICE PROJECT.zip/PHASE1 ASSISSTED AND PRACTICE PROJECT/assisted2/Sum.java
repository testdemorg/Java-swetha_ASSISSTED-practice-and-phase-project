package assisted2;

public class Sum {

}
