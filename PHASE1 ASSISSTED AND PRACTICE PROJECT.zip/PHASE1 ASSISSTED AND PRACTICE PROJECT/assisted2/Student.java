package assisted2;

public class Student {
	
	int id;
	String name;

	public static void main(String args[]) {
		Student s1 = new Student();
		
		s1.id=4;
		s1.name="xyz";
		System.out.println(s1.id+" "+s1.name);
		
	}
	}


